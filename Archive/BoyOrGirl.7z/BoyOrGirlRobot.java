import java.io.IOException;
import static java.awt.event.KeyEvent.*;
import java.util.Arrays;

class BoyOrGirlRobot {

    public static void main(String[] args) {

        try {

            /* создаём экземпляр считывателя базы данных MagicDistancesDataSetReader */
            MagicDistancesDataSetReader dataSetReader = new MagicDistancesDataSetReader();

            /* теперь создаём экзмепляр нейронную сеть */
            NetworkOne network = new NetworkOne(2 * 68, /* Количество входных нейронов */
                                               new int[] {30, 1} /* Первый и второй (последний) слои */);

            /* инициализируем параметры обучения */
            network.LEARNING_RATE = 1;
            network.DELTA_W = 0.01;
            network.randomWeightAdditionRange = 1;
            
            network.initializeWeightsWithNormalRandomNumbers();

            /* создаём валидатор */
			NeuralOneOrZeroValidator validator = new NeuralOneOrZeroValidator(network, dataSetReader.magicDistances, dataSetReader.bitNumber);
            
            /* устанавливаем набор данных обучения */
            network.setTrainingSet(dataSetReader.magicDistances, dataSetReader.desiredOutputs);

          

            ArtConsole console = new ArtConsole();
            int keyCode = 0;


			console.println("Preliminary validation (must be ~50%): " + validator.validate(0, 1000 - 1) + " / " + 1000);




            
            double error = 0;

            boolean backpropagationAllowed = true;
            int numberOfBackpropCycles = 50;

            boolean randomWalkAllowed = false;
            int numberOfRandomWalkCycles = 20;

            int miniBatchSize = 10000;

            console.println("Calculating mean square error");
            network.setCurrentMiniBatchRange(0, dataSetReader.TOTAL_NUMBER_OF_FACES - 1);
            error = network.getMeanSquareError();
		    console.println("Ready");            
            System.err.println(error);

            int epoch = 0;
            
            /* Сохраняем время запуска программы */
            long programStartTime = System.currentTimeMillis();

            while (true) {
                if (console.keyPressed) { /* Обработка нажатий клавиш */
                    console.clearKey();
                    keyCode = console.keyCode;

                    if (keyCode == VK_ADD) {
                        network.LEARNING_RATE *= 1.1;
                        console.println("Increasing Learning rate! Now Learning rate is " + network.LEARNING_RATE);
                    }

                    if (keyCode == VK_SUBTRACT) {
                        network.LEARNING_RATE /= 1.1;
                        console.println("Decreasing Learning rate! Now Learning rate is " + network.LEARNING_RATE);
                    }

                    if (keyCode == VK_MULTIPLY) {
                        network.LEARNING_RATE *= 10;
                        console.println("Increasing Learning rate! Now Learning rate is " + network.LEARNING_RATE);
                    }

                    if (keyCode == VK_DIVIDE) {
                        network.LEARNING_RATE /= 10;
                        console.println("Decreasing Learning rate! Now Learning rate is " + network.LEARNING_RATE);
                    }


                    if (keyCode == VK_PAGE_UP) {
                        network.randomWeightAdditionRange *= 2;
                        console.println("Increasing Random step max size! Now it is " + network.randomWeightAdditionRange);
                    }

                    if (keyCode == VK_PAGE_DOWN) {
                        network.randomWeightAdditionRange /= 2;
                        console.println("Decreasing random step max size! Now it is " + network.randomWeightAdditionRange);
                    }

                    
                    if (keyCode == VK_R) {
                        console.println("Reinitializing weights");
                        network.initializeWeightsWithNormalRandomNumbers();
                        programStartTime = System.currentTimeMillis();
                    }

                    if (keyCode == VK_Z) {
                        console.println("Zeroing weights");
                        ArtiomArrayUtils.zeroFill3DArray(network.weight);
                        programStartTime = System.currentTimeMillis();
                    }

                    
                    if (keyCode == VK_B)
                        backpropagationAllowed = !backpropagationAllowed;

                    if (keyCode == VK_F)
                        randomWalkAllowed = !randomWalkAllowed;



                    


                } /* Обработка клавиш */



                epoch++;
                long cycleStartTime = System.currentTimeMillis();

                for (int i=0; i + miniBatchSize - 1 <= dataSetReader.TOTAL_NUMBER_OF_FACES; i += miniBatchSize) {

                    /* Устанавливаем границы мини-пакета в цикле по тренировочным данным */
                    network.setCurrentMiniBatchRange(i, i + miniBatchSize - 1);

                    /* Минимизируем функцию ошибки на данном мини-пакете */
                    network.teachWithBackpropagation(1);

                    if (randomWalkAllowed) network.teachByShakingWeights(1);

                    if (i % 5000 == 0) {
                        console.print("▒");
                    }



                  
                    
                }



                /* Вычисляем ошибку на всём тренировочном наборе (можно заменить на случайный промежуток впоследствии) */
                network.setCurrentMiniBatchRange(0 , dataSetReader.TOTAL_NUMBER_OF_FACES - 1);

                error = network.getMeanSquareError();

                console.clearScreen();

                /* Печать ошибки, количество успешных распознаваний и модуль градиента */
                System.err.println(error);
                console.println("\nCost function: " + error);
                console.println("Validation: " + validator.validate(0, 1000 - 1) + " / " + 1000 + "\n");
                console.println("Cost gradient absolude value: " + ArtiomArrayUtils.abs(network.costGradient));

                console.println("Backpropagation: " + (backpropagationAllowed? "ON " : "OFF") + "\nRandom walk: " + (randomWalkAllowed? "ON" : "OFF"));
                console.println("Training with:\n    Learning rate: " + network.LEARNING_RATE + 
                                "\n    Random max step: " + network.randomWeightAdditionRange +
                                "\nMini-batch size: " + miniBatchSize + "\n");
            
                
                console.println("Time spent on the last training cycle: " + (System.currentTimeMillis() - cycleStartTime) + " ms");
                console.println("Time elapsed: " + (System.currentTimeMillis() - programStartTime) / 1000 + " seconds");
                console.println("Epoch number: " + epoch);
                
                
            }

            /*
            System.out.println("Bye! See you soon!");
            System.exit(0);
            */



       } /* Выше - если не было ошибки с открытием базы данных с цифрами MNIST */

       catch (IOException e) {
           System.out.println("Error opening MNIST data base! Exiting.");
       }
    }

}

